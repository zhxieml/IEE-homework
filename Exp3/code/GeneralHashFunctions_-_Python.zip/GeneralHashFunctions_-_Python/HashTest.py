from GeneralHashFunctions import *

print RSHash  ('abcdefghijklmnopqrstuvwxyz1234567890')
print JSHash  ('abcdefghijklmnopqrstuvwxyz1234567890')
print PJWHash ('abcdefghijklmnopqrstuvwxyz1234567890')
print ELFHash ('abcdefghijklmnopqrstuvwxyz1234567890')
print BKDRHash('abcdefghijklmnopqrstuvwxyz1234567890')
print SDBMHash('abcdefghijklmnopqrstuvwxyz1234567890')
print DJBHash ('abcdefghijklmnopqrstuvwxyz1234567890')
print DEKHash ('abcdefghijklmnopqrstuvwxyz1234567890')
print BPHash  ('abcdefghijklmnopqrstuvwxyz1234567890')
print FNVHash ('abcdefghijklmnopqrstuvwxyz1234567890')
print APHash  ('abcdefghijklmnopqrstuvwxyz1234567890')
